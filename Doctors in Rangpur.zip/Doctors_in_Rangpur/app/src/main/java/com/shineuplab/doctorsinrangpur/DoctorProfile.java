package com.shineuplab.doctorsinrangpur;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class DoctorProfile extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_profile);

        TextView NameTv = findViewById(R.id.NameTv);
        TextView SpTv = findViewById(R.id.SpTv);
        TextView  DayTv = findViewById(R.id.DayTv);
        TextView TimeTv = findViewById(R.id.TimeTv);
        TextView EduTv = findViewById(R.id.EduTv);
        TextView WorkTv  = findViewById(R.id.WorkTv);
        TextView PhoneTv = findViewById(R.id.PhoneTv);
        TextView ChamberTv = findViewById(R.id.ChamberTv);

        Button Serial = findViewById(R.id.SerialBtnId);


        NameTv.setText(getIntent().getExtras().getString("name"));
        SpTv.setText(getIntent().getExtras().getString("sp"));
        DayTv.setText(getIntent().getExtras().getString("day"));
        TimeTv.setText(getIntent().getExtras().getString("time"));
        EduTv.setText(getIntent().getExtras().getString("edu"));
        WorkTv.setText(getIntent().getExtras().getString("work"));
        PhoneTv.setText(getIntent().getExtras().getString("phone"));
        ChamberTv.setText(getIntent().getExtras().getString("chamber"));
        Serial.setText(getIntent().getExtras().getString("serial"));

    }
}
