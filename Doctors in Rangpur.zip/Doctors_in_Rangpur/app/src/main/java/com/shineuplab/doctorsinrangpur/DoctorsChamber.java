package com.shineuplab.doctorsinrangpur;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DoctorsChamber extends AppCompatActivity implements View.OnClickListener {

    CardView PopularOneCv, PopularTwoCv, LabAidCv, UpdateCv, DoctorsCv, HyperCv, KasirCv, IslamiCv, SebaCv, AnnexCv, ApolloCv, RddcCv, PpCv, SunCv, CentralCv, RangpurCityScanCv, MetroLabCv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors_chamber);


        PopularOneCv = findViewById(R.id.PopularOneCvId);
        PopularTwoCv = findViewById(R.id.PopularTwoCvId);
        LabAidCv = findViewById(R.id.LabAidCvId);
        UpdateCv = findViewById(R.id.UpdateCvId);
        DoctorsCv = findViewById(R.id.DoctorsCvId);
        HyperCv = findViewById(R.id.HyperCvId);
        KasirCv = findViewById(R.id.KasirCvId);
        IslamiCv = findViewById(R.id.IslamiCvId);
        SebaCv = findViewById(R.id.SebaCvId);
        AnnexCv = findViewById(R.id.AnnexCvId);
        ApolloCv = findViewById(R.id.ApolloCvId);
        RddcCv = findViewById(R.id.RddcCvId);
        PpCv = findViewById(R.id.PpCvId);
        SunCv = findViewById(R.id.SunCvId);
        RangpurCityScanCv = findViewById(R.id.RangpurCityScanCvId);
        CentralCv = findViewById(R.id.CentralCvId);
        MetroLabCv = findViewById(R.id.MetroLabCvId);

        PopularOneCv.setOnClickListener(this);
        PopularTwoCv.setOnClickListener(this);
        LabAidCv.setOnClickListener(this);
        UpdateCv.setOnClickListener(this);
        DoctorsCv.setOnClickListener(this);
        HyperCv.setOnClickListener(this);
        KasirCv.setOnClickListener(this);
        IslamiCv.setOnClickListener(this);
        SebaCv.setOnClickListener(this);
        AnnexCv.setOnClickListener(this);
        ApolloCv.setOnClickListener(this);
        RddcCv.setOnClickListener(this);
        PpCv.setOnClickListener(this);
        SunCv.setOnClickListener(this);
        RangpurCityScanCv.setOnClickListener(this);
        CentralCv.setOnClickListener(this);
        MetroLabCv.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if (view.getId()==R.id.PopularOneCvId){
            Intent intent = new Intent(getApplicationContext(), PopularDcOne.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.PopularTwoCvId){
            Intent intent = new Intent(getApplicationContext(), PopularDcTwo.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.LabAidCvId){
            Intent intent = new Intent(getApplicationContext(), LabAidDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.UpdateCvId){
            Intent intent = new Intent(getApplicationContext(), UpdateDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.SunCvId){
            Intent intent = new Intent(getApplicationContext(), SunDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.RddcCvId){
            Intent intent = new Intent(getApplicationContext(), RangpurDigitalDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.RangpurCityScanCvId){
            Intent intent = new Intent(getApplicationContext(), RangpurCityScanDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.PpCvId){
            Intent intent = new Intent(getApplicationContext(), PrescriptionPointDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.KasirCvId){
            Intent intent = new Intent(getApplicationContext(), KasirUddinDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.HyperCvId){
            Intent intent = new Intent(getApplicationContext(), HyperTensionDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.DoctorsCvId) {
            Intent intent = new Intent(getApplicationContext(), DoctorsDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.IslamiCvId){
            Intent intent = new Intent(getApplicationContext(), IslamiBankDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.ApolloCvId){
            Intent intent = new Intent(getApplicationContext(), ApolloDc.class);
            startActivity(intent);
        }
        if (view.getId()==R.id.MetroLabCvId){
            Intent intent = new Intent(getApplicationContext(), MetroLabDc.class);
            startActivity(intent);
        }

    }
}
