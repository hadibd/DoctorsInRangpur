package com.shineuplab.doctorsinrangpur;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class PopularDcOne extends AppCompatActivity implements View.OnClickListener {

    public static String KEY_NAME = "1";
    public static String KEY_SP = "2";
    public static String KEY_DAY = "3";
    public static String KEY_TIME = "4";
    public static String KEY_EDU = "5";
    public static String KEY_WORK = "6";
    public static String KEY_PHONE = "7";
    public static String KEY_CHAMBER = "8";
    public static String KEY_SERIAL = "9";

    public static String KEY_DOCUMENT_NAME = "popular_one";

    TextView doctorNameTv1, doctorNameTv2, doctorNameTv3, doctorNameTv4, doctorNameTv5, doctorNameTv6, doctorNameTv7, doctorNameTv8, doctorNameTv9, doctorNameTv10;
    TextView doctorNameTv11, doctorNameTv12, doctorNameTv13, doctorNameTv14, doctorNameTv15, doctorNameTv16, doctorNameTv17, doctorNameTv18, doctorNameTv19, doctorNameTv20;
    TextView doctorNameTv21, doctorNameTv22, doctorNameTv23, doctorNameTv24, doctorNameTv25, doctorNameTv26;

    TextView doctorSpTv1, doctorSpTv2, doctorSpTv3, doctorSpTv4, doctorSpTv5, doctorSpTv6, doctorSpTv7, doctorSpTv8, doctorSpTv9, doctorSpTv10;
    TextView doctorSpTv11, doctorSpTv12, doctorSpTv13, doctorSpTv14, doctorSpTv15, doctorSpTv16, doctorSpTv17, doctorSpTv18, doctorSpTv19, doctorSpTv20;
    TextView doctorSpTv21, doctorSpTv22, doctorSpTv23, doctorSpTv24, doctorSpTv25, doctorSpTv26;

    LinearLayout doctor01, doctor02, doctor03, doctor04, doctor05, doctor06, doctor07, doctor08, doctor09, doctor10;
    LinearLayout doctor11, doctor12, doctor13, doctor14, doctor15, doctor16, doctor17, doctor18, doctor19, doctor20;
    LinearLayout doctor21, doctor22, doctor23, doctor24, doctor25, doctor26;

    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_popular_dc_one);

        doctorNameTv1 = findViewById(R.id.doctorNameTv1);
        doctorNameTv2 = findViewById(R.id.doctorNameTv2);
        doctorNameTv3 = findViewById(R.id.doctorNameTv3);
        doctorNameTv4 = findViewById(R.id.doctorNameTv4);
        doctorNameTv5 = findViewById(R.id.doctorNameTv5);
        doctorNameTv6 = findViewById(R.id.doctorNameTv6);
        doctorNameTv7 = findViewById(R.id.doctorNameTv7);
        doctorNameTv8 = findViewById(R.id.doctorNameTv8);
        doctorNameTv9 = findViewById(R.id.doctorNameTv9);
        doctorNameTv10 = findViewById(R.id.doctorNameTv10);
        doctorNameTv11 = findViewById(R.id.doctorNameTv11);
        doctorNameTv12 = findViewById(R.id.doctorNameTv12);
        doctorNameTv13 = findViewById(R.id.doctorNameTv13);
        doctorNameTv14 = findViewById(R.id.doctorNameTv14);
        doctorNameTv15 = findViewById(R.id.doctorNameTv15);
        doctorNameTv16 = findViewById(R.id.doctorNameTv16);
        doctorNameTv17 = findViewById(R.id.doctorNameTv17);
        doctorNameTv18 = findViewById(R.id.doctorNameTv18);
        doctorNameTv19 = findViewById(R.id.doctorNameTv19);
        doctorNameTv20 = findViewById(R.id.doctorNameTv20);
        doctorNameTv21 = findViewById(R.id.doctorNameTv21);
        doctorNameTv22 = findViewById(R.id.doctorNameTv22);
        doctorNameTv23 = findViewById(R.id.doctorNameTv23);
        doctorNameTv24 = findViewById(R.id.doctorNameTv24);
        doctorNameTv25 = findViewById(R.id.doctorNameTv25);
        doctorNameTv26 = findViewById(R.id.doctorNameTv26);

        doctorSpTv1 = findViewById(R.id.doctorSpTv1);
        doctorSpTv2 = findViewById(R.id.doctorSpTv2);
        doctorSpTv3 = findViewById(R.id.doctorSpTv3);
        doctorSpTv4 = findViewById(R.id.doctorSpTv4);
        doctorSpTv5 = findViewById(R.id.doctorSpTv5);
        doctorSpTv6 = findViewById(R.id.doctorSpTv6);
        doctorSpTv7 = findViewById(R.id.doctorSpTv7);
        doctorSpTv8 = findViewById(R.id.doctorSpTv8);
        doctorSpTv9 = findViewById(R.id.doctorSpTv9);
        doctorSpTv10 = findViewById(R.id.doctorSpTv10);
        doctorSpTv11 = findViewById(R.id.doctorSpTv11);
        doctorSpTv12 = findViewById(R.id.doctorSpTv12);
        doctorSpTv13 = findViewById(R.id.doctorSpTv13);
        doctorSpTv14 = findViewById(R.id.doctorSpTv14);
        doctorSpTv15 = findViewById(R.id.doctorSpTv15);
        doctorSpTv16 = findViewById(R.id.doctorSpTv16);
        doctorSpTv17 = findViewById(R.id.doctorSpTv17);
        doctorSpTv18 = findViewById(R.id.doctorSpTv18);
        doctorSpTv19 = findViewById(R.id.doctorSpTv19);
        doctorSpTv20 = findViewById(R.id.doctorSpTv20);
        doctorSpTv21 = findViewById(R.id.doctorSpTv21);
        doctorSpTv22 = findViewById(R.id.doctorSpTv22);
        doctorSpTv23 = findViewById(R.id.doctorSpTv23);
        doctorSpTv24 = findViewById(R.id.doctorSpTv24);
        doctorSpTv25 = findViewById(R.id.doctorSpTv25);
        doctorSpTv26 = findViewById(R.id.doctorSpTv26);

        doctor01 = findViewById(R.id.Doctor01);
        doctor02 = findViewById(R.id.Doctor02);
        doctor03 = findViewById(R.id.Doctor03);
        doctor04 = findViewById(R.id.Doctor04);
        doctor05 = findViewById(R.id.Doctor05);
        doctor06 = findViewById(R.id.Doctor06);
        doctor07 = findViewById(R.id.Doctor07);
        doctor08 = findViewById(R.id.Doctor08);
        doctor09 = findViewById(R.id.Doctor09);
        doctor10 = findViewById(R.id.Doctor10);
        doctor11 = findViewById(R.id.Doctor11);
        doctor12 = findViewById(R.id.Doctor12);
        doctor13 = findViewById(R.id.Doctor13);
        doctor14 = findViewById(R.id.Doctor14);
        doctor15 = findViewById(R.id.Doctor15);
        doctor16 = findViewById(R.id.Doctor16);
        doctor17 = findViewById(R.id.Doctor17);
        doctor18 = findViewById(R.id.Doctor18);
        doctor19 = findViewById(R.id.Doctor19);
        doctor20 = findViewById(R.id.Doctor20);
        doctor21 = findViewById(R.id.Doctor21);
        doctor22 = findViewById(R.id.Doctor22);
        doctor23 = findViewById(R.id.Doctor23);
        doctor24 = findViewById(R.id.Doctor24);
        doctor25 = findViewById(R.id.Doctor25);
        doctor26 = findViewById(R.id.Doctor26);

        doctor01.setOnClickListener(this);
        doctor02.setOnClickListener(this);
        doctor03.setOnClickListener(this);
        doctor04.setOnClickListener(this);
        doctor05.setOnClickListener(this);
        doctor06.setOnClickListener(this);
        doctor07.setOnClickListener(this);
        doctor08.setOnClickListener(this);
        doctor09.setOnClickListener(this);
        doctor10.setOnClickListener(this);
        doctor11.setOnClickListener(this);
        doctor12.setOnClickListener(this);
        doctor13.setOnClickListener(this);
        doctor14.setOnClickListener(this);
        doctor15.setOnClickListener(this);
        doctor16.setOnClickListener(this);
        doctor17.setOnClickListener(this);
        doctor18.setOnClickListener(this);
        doctor19.setOnClickListener(this);
        doctor20.setOnClickListener(this);
        doctor21.setOnClickListener(this);
        doctor22.setOnClickListener(this);
        doctor23.setOnClickListener(this);
        doctor24.setOnClickListener(this);
        doctor25.setOnClickListener(this);
        doctor26.setOnClickListener(this);


        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("01").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv1.setText(mName);
                            doctorSpTv1.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("02").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv2.setText(mName);
                            doctorSpTv2.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("03").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv3.setText(mName);
                            doctorSpTv3.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("04").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv4.setText(mName);
                            doctorSpTv4.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("05").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv5.setText(mName);
                            doctorSpTv5.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("06").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv6.setText(mName);
                            doctorSpTv6.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("07").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv7.setText(mName);
                            doctorSpTv7.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("08").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv8.setText(mName);
                            doctorSpTv8.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("09").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv9.setText(mName);
                            doctorSpTv9.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("10").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv10.setText(mName);
                            doctorSpTv10.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("11").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv11.setText(mName);
                            doctorSpTv11.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("12").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv12.setText(mName);
                            doctorSpTv12.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("13").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv13.setText(mName);
                            doctorSpTv13.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("14").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv14.setText(mName);
                            doctorSpTv14.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("15").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv15.setText(mName);
                            doctorSpTv15.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("16").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv16.setText(mName);
                            doctorSpTv16.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("17").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv17.setText(mName);
                            doctorSpTv17.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("18").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv18.setText(mName);
                            doctorSpTv18.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("19").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv19.setText(mName);
                            doctorSpTv19.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("20").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv20.setText(mName);
                            doctorSpTv20.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("21").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv21.setText(mName);
                            doctorSpTv21.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("22").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv22.setText(mName);
                            doctorSpTv22.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("23").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv23.setText(mName);
                            doctorSpTv23.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("24").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv24.setText(mName);
                            doctorSpTv24.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("25").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv25.setText(mName);
                            doctorSpTv25.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("26").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv26.setText(mName);
                            doctorSpTv26.setText(mPlace);
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.Doctor01) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("01").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor02) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("02").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor03) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("03").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor04) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("04").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor05) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("05").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor06) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("06").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor07) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("07").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor08) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("08").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor09) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("09").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor10) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("10").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor11) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("11").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor12) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("12").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor13) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("13").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor14) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("14").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor15) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("15").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor16) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("16").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor17) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("17").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor18) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("18").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor19) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("19").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor20) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("20").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor21) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("21").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor22) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("22").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor23) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("23").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor24) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("24").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor25) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("25").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor26) {

            firebaseFirestore.collection(KEY_DOCUMENT_NAME).document("26").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
    }
}
