package com.shineuplab.doctorsinrangpur;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class PrescriptionPointDc extends AppCompatActivity implements View.OnClickListener {

    public static String KEY_NAME = "1";
    public static String KEY_SP = "2";
    public static String KEY_DAY = "3";
    public static String KEY_TIME = "4";
    public static String KEY_EDU = "5";
    public static String KEY_WORK = "6";
    public static String KEY_PHONE = "7";
    public static String KEY_CHAMBER = "8";
    public static String KEY_SERIAL = "9";

    TextView doctorNameTv1, doctorNameTv2, doctorNameTv3, doctorNameTv4, doctorNameTv5, doctorNameTv6, doctorNameTv7;

    TextView doctorSpTv1, doctorSpTv2, doctorSpTv3, doctorSpTv4, doctorSpTv5, doctorSpTv6, doctorSpTv7;

    LinearLayout doctor01, doctor02, doctor03, doctor04, doctor05, doctor06, doctor07;

    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prescription_point_dc);

        this.setTitle(R.string.popular_en_one);

        doctorNameTv1 = findViewById(R.id.doctorNameTv1);
        doctorNameTv2 = findViewById(R.id.doctorNameTv2);
        doctorNameTv3 = findViewById(R.id.doctorNameTv3);
        doctorNameTv4 = findViewById(R.id.doctorNameTv4);
        doctorNameTv5 = findViewById(R.id.doctorNameTv5);
        doctorNameTv6 = findViewById(R.id.doctorNameTv6);
        doctorNameTv7 = findViewById(R.id.doctorNameTv7);

        doctorSpTv1 = findViewById(R.id.doctorSpTv1);
        doctorSpTv2 = findViewById(R.id.doctorSpTv2);
        doctorSpTv3 = findViewById(R.id.doctorSpTv3);
        doctorSpTv4 = findViewById(R.id.doctorSpTv4);
        doctorSpTv5 = findViewById(R.id.doctorSpTv5);
        doctorSpTv6 = findViewById(R.id.doctorSpTv6);
        doctorSpTv7 = findViewById(R.id.doctorSpTv7);

        doctor01 = findViewById(R.id.Doctor01);
        doctor02 = findViewById(R.id.Doctor02);
        doctor03 = findViewById(R.id.Doctor03);
        doctor04 = findViewById(R.id.Doctor04);
        doctor05 = findViewById(R.id.Doctor05);
        doctor06 = findViewById(R.id.Doctor06);
        doctor07 = findViewById(R.id.Doctor07);

        doctor01.setOnClickListener(this);
        doctor02.setOnClickListener(this);
        doctor03.setOnClickListener(this);
        doctor04.setOnClickListener(this);
        doctor05.setOnClickListener(this);
        doctor06.setOnClickListener(this);
        doctor07.setOnClickListener(this);

        firebaseFirestore.collection("pp").document("01").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv1.setText(mName);
                            doctorSpTv1.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("02").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv2.setText(mName);
                            doctorSpTv2.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("03").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv3.setText(mName);
                            doctorSpTv3.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("04").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv4.setText(mName);
                            doctorSpTv4.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("05").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv5.setText(mName);
                            doctorSpTv5.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("06").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv6.setText(mName);
                            doctorSpTv6.setText(mPlace);
                        }
                    }
                });
        firebaseFirestore.collection("pp").document("07").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {

                            String mName = documentSnapshot.getString(KEY_NAME);
                            String mPlace = documentSnapshot.getString(KEY_SP);

                            doctorNameTv7.setText(mName);
                            doctorSpTv7.setText(mPlace);
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.Doctor01) {

            firebaseFirestore.collection("pp").document("01").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor02) {

            firebaseFirestore.collection("pp").document("02").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor03) {

            firebaseFirestore.collection("pp").document("03").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor04) {

            firebaseFirestore.collection("pp").document("04").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor05) {

            firebaseFirestore.collection("pp").document("05").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor06) {

            firebaseFirestore.collection("pp").document("06").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
        if (view.getId() == R.id.Doctor07) {

            firebaseFirestore.collection("pp").document("07").get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {

                                String mName = documentSnapshot.getString(KEY_NAME);
                                String mSp = documentSnapshot.getString(KEY_SP);
                                String mDay = documentSnapshot.getString(KEY_DAY);
                                String mTime = documentSnapshot.getString(KEY_TIME);
                                String mEdu = documentSnapshot.getString(KEY_EDU);
                                String mWork = documentSnapshot.getString(KEY_WORK);
                                String mPhone = documentSnapshot.getString(KEY_PHONE);
                                String mChamber = documentSnapshot.getString(KEY_CHAMBER);
                                String mSerial = documentSnapshot.getString(KEY_SERIAL);

                                Intent intent = new Intent(getApplicationContext(), DoctorProfile.class);
                                intent.putExtra("name", mName);
                                intent.putExtra("sp", mSp);
                                intent.putExtra("day", mDay);
                                intent.putExtra("time", mTime);
                                intent.putExtra("edu", mEdu);
                                intent.putExtra("work", mWork);
                                intent.putExtra("phone", mPhone);
                                intent.putExtra("chamber", mChamber);
                                intent.putExtra("serial", mSerial);
                                startActivity(intent);
                            }
                        }
                    });

        }
    }

}